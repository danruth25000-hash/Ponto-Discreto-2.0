package br.com.demonstracao.pontodiscreto;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.*;
import android.net.Uri;
import androidx.core.app.ActivityCompat;
import com.google.android.gms.location.*;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout root, content;
    private FusedLocationProviderClient fused;
    private TextView gpsText, statusText;
    private double lat = Double.NaN, lon = Double.NaN;
    private static final int REQ_LOC = 44;
    private final String[] layers = {
        "Imagem de satélite (requer internet ou pacote offline)",
        "Mapa geológico SGB — Roraima",
        "Recursos minerais / ocorrências — SGB",
        "Processos minerários ativos — ANM",
        "Áreas de bloqueio — ANM",
        "Reservas garimpeiras — ANM",
        "Hidrografia — SEPLAN/RR",
        "Solos e pedologia — IBGE/SEPLAN",
        "Relevo / geomorfologia — IBGE/SEPLAN",
        "Limites e áreas institucionais — ZEE-RR"
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        fused = LocationServices.getFusedLocationProviderClient(this);
        home();
    }

    private void base(String title) {
        root = new LinearLayout(this);
        root.setOrientation(1);
        root.setPadding(24, 22, 24, 18);
        root.setBackgroundColor(Color.WHITE);
        TextView h = new TextView(this);
        h.setText(title); h.setTextSize(23); h.setTypeface(null, Typeface.BOLD);
        h.setTextColor(Color.rgb(35,45,48));
        root.addView(h);
        content = new LinearLayout(this); content.setOrientation(1);
        content.setPadding(0,18,0,0);
        ScrollView sc = new ScrollView(this); sc.addView(content);
        root.addView(sc, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    private TextView text(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.rgb(55,65,68)); t.setPadding(0,8,0,8); return t;
    }
    private Button btn(String s, Runnable r) {
        Button b = new Button(this); b.setText(s); b.setOnClickListener(v -> r.run());
        content.addView(b); return b;
    }
    private void home() {
        base("Ponto Discreto · RR");
        content.addView(text("Pesquisa mineral e caderno de campo",16));
        content.addView(text("Ferramenta de apoio: mapas e indicadores geológicos não confirmam ouro. Confirmação exige amostragem e análise laboratorial.",14));
        btn("📍 Capturar minha posição GPS", this::getGps);
        gpsText = text("GPS: aguardando captura",14); content.addView(gpsText);
        btn("＋ Registrar ponto de pesquisa", this::newPoint);
        btn("▤ Camadas e fontes cartográficas", this::layerPage);
        btn("▣ Caderno de campo salvo", this::records);
        btn("⬇ Fontes oficiais para mapas offline", this::offlineInfo);
        content.addView(text("Roraima · Datum das bases deve ser conferido em cada camada · dados podem ter datas diferentes.",12));
    }
    private void getGps() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC); return;
        }
        fused.getLastLocation().addOnSuccessListener(this, loc -> {
            if (loc != null) {
                lat=loc.getLatitude(); lon=loc.getLongitude();
                gpsText.setText(String.format(Locale.US,"GPS: %.6f, %.6f\nPrecisão informada: %.1f m",lat,lon,loc.getAccuracy()));
            } else gpsText.setText("Sem posição recente. Ative a localização e tente novamente ao ar livre.");
        });
    }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g); if(r==REQ_LOC && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) getGps();
    }
    private void newPoint() {
        base("Novo ponto de pesquisa");
        EditText name = field("Nome do ponto (ex.: Afloramento 01)");
        EditText notes = field("Observações geológicas, rocha, solo, drenagem...");
        EditText sample = field("Código da amostra (opcional)");
        content.addView(text(Double.isNaN(lat)?"GPS ainda não capturado":String.format(Locale.US,"Coordenadas: %.6f, %.6f",lat,lon),14));
        btn("Salvar no aparelho", () -> {
            String stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date());
            String rec = stamp+" | "+name.getText()+" | "+(Double.isNaN(lat)?"sem GPS":lat+","+lon)+" | Amostra: "+sample.getText()+" | "+notes.getText()+"\n";
            try {
                File f = new File(getFilesDir(),"caderno_campo.txt");
                FileOutputStream o = new FileOutputStream(f,true); o.write(rec.getBytes("UTF-8")); o.close();
                Toast.makeText(this,"Registro salvo neste aparelho",Toast.LENGTH_LONG).show(); home();
            } catch(Exception e) { Toast.makeText(this,"Erro ao salvar",Toast.LENGTH_SHORT).show(); }
        });
        btn("Voltar",this::home);
    }
    private EditText field(String hint) {
        EditText e = new EditText(this); e.setHint(hint); content.addView(e); return e;
    }
    private void layerPage() {
        base("Camadas cartográficas");
        content.addView(text("Catálogo de camadas previstas para Roraima. A inclusão no catálogo não significa que os dados já estejam baixados no aparelho.",14));
        for(String s:layers) content.addView(text("• "+s,14));
        btn("Abrir mapa geológico SGB", () -> open("https://geosgb.sgb.gov.br/downloads/"));
        btn("Abrir mapas SEPLAN/RR", () -> open("https://seplan.rr.gov.br/mapoteca/"));
        btn("Abrir dados SIGMINE/ANM — RR", () -> open("https://dadosabertos.anm.gov.br/SIGMINE/PROCESSOS_MINERARIOS/RR.zip"));
        btn("Voltar",this::home);
    }
    private void offlineInfo() {
        base("Uso sem internet");
        content.addView(text("O GPS funciona sem internet, mas mapas e imagens precisam ser baixados previamente. Esta versão 2.0 registra coordenadas e notas offline; ainda não inclui mapas raster/tiles nem os arquivos vetoriais oficiais no armazenamento offline.",14));
        content.addView(text("Antes de ir a campo, baixe no aparelho os mapas oficiais e dados vetoriais. Confira data, escala, sistema de coordenadas e licença. Não trate camadas antigas como situação atual.",14));
        btn("Abrir downloads geológicos SGB", () -> open("https://geosgb.sgb.gov.br/downloads/"));
        btn("Abrir Mapoteca SEPLAN/RR", () -> open("https://seplan.rr.gov.br/mapoteca/"));
        btn("Abrir dados ANM de Roraima", () -> open("https://dadosabertos.anm.gov.br/SIGMINE/PROCESSOS_MINERARIOS/RR.zip"));
        btn("Voltar",this::home);
    }
    private void records() {
        base("Caderno de campo");
        File f = new File(getFilesDir(),"caderno_campo.txt");
        if(!f.exists()) content.addView(text("Nenhum registro salvo ainda.",14));
        else try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f),"UTF-8"));
            String line; while((line=br.readLine())!=null) content.addView(text(line,13)); br.close();
        } catch(Exception e) { content.addView(text("Não foi possível ler os registros.",14)); }
        btn("Voltar",this::home);
    }
    private void open(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch(Exception e) { Toast.makeText(this,"Não foi possível abrir o link",Toast.LENGTH_SHORT).show(); }
    }
}
